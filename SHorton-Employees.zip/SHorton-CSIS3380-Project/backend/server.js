import express from "express";
import mongoose from "mongoose";
import bodyparser from "body-parser";
import cors from "cors";
import routesBasic from "./routes/employeeBasicInfoRoutes";
import routesSecondary from "./routes/employeeSecondaryInfoRoutes";

// set up express
const app = express();

// set port
const PORT = 5000;

//mongo connection
mongoose.Promise = global.Promise;
mongoose.connect("mongodb://localhost/employee_db", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// bodyparser set up
app.use(bodyparser.urlencoded({ extended: true }));
app.use(bodyparser.json());

// set up cors
app.use(cors());

//add routes
routesBasic(app);
routesSecondary(app);

// make sure the app is running
app.get("/", (req, res) =>
  res.send(`The employee application server is running on port ${PORT}`)
);

app.listen(PORT, () =>
  console.log(`The employee application server is running on port ${PORT}`)
);
