import mongoose from "mongoose";

const Schema = mongoose.Schema;

export const employeeBasicInfoSchema = new Schema({
  first_name: {
    type: String,
    required: true,
  },
  last_name: {
    type: String,
    required: true,
  },
  gender: {
    type: String,
  },
  resume_received: {
    type: Boolean,
  },
  coverletter_received: {
    type: Boolean,
  },
});

export const employeeSecondaryInfoSchema = new Schema({
  email: {
    type: String,
  },
  phone_number: {
    type: String,
  },
  job_title: {
    type: String,
  },
  SSN: {
    type: String,
  },
  special_skills: {
    type: String,
  },
});
