import {
  addNewEmployeeSecondaryInformation,
  getEmployeesSecondary,
  getEmployeeSecondaryWithID,
  updateSecondaryEmployee,
  deleteSecondaryEmployee,
} from "../config/employeeControllers";

const routesSecondary = (app) => {
  app
    .route("/employeeSecondary")

    //GET endpoint
    .get(getEmployeesSecondary)

    //POST endpoint
    .post(addNewEmployeeSecondaryInformation);

  app
    .route("/employeeSecondary/:EmployeeSecondaryId")
    //get one employees secondary information by id
    .get(getEmployeeSecondaryWithID)
    // update one employees secondary information
    .put(updateSecondaryEmployee)
    //delete one employees secondary information
    .delete(deleteSecondaryEmployee);
};

export default routesSecondary;
