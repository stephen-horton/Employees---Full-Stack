import {
  addNewEmployeeBasicInformation,
  getEmployeesBasic,
  getEmployeeBasicWithID,
  updateBasicEmployee,
  deleteBasicEmployee,
} from "../config/employeeControllers";

const routesBasic = (app) => {
  app
    .route("/employeeBasic")

    //GET endpoint
    .get(getEmployeesBasic)

    //POST endpoint
    .post(addNewEmployeeBasicInformation);

  app
    .route("/employeeBasic/:EmployeeBasicId")
    // get one employees basic information
    .get(getEmployeeBasicWithID)
    //update one employees basic information
    .put(updateBasicEmployee)
    //delete one employees basic information
    .delete(deleteBasicEmployee);
};

export default routesBasic;
