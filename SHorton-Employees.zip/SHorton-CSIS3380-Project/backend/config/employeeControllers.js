import mongoose from "mongoose";
import {
  employeeBasicInfoSchema,
  employeeSecondaryInfoSchema,
} from "../models/employeeModel";

//basic employee
const EmployeeBasic = mongoose.model("EmployeeBasic", employeeBasicInfoSchema);

//add basic employee information
export const addNewEmployeeBasicInformation = (req, res) => {
  let newEmployee = new EmployeeBasic(req.body);

  newEmployee.save((err, EmployeeBasic) => {
    if (err) {
      res.send(err);
    }
    res.json(EmployeeBasic);
  });
};

// get all employees basic informaiton
export const getEmployeesBasic = (req, res) => {
  EmployeeBasic.find({}, (err, EmployeeBasic) => {
    if (err) {
      res.send(err);
    }
    res.json(EmployeeBasic);
  });
};

//get one employees basic information by id
export const getEmployeeBasicWithID = (req, res) => {
  EmployeeBasic.findById(req.params.EmployeeBasicId, (err, EmployeeBasic) => {
    if (err) {
      res.send(err);
    }
    res.json(EmployeeBasic);
  });
};

//update one employees basic information
export const updateBasicEmployee = (req, res) => {
  EmployeeBasic.findOneAndUpdate(
    { _id: req.params.EmployeeBasicId },
    req.body,
    { new: true },
    (err, EmployeeBasic) => {
      if (err) {
        res.send(err);
      }
      res.json(EmployeeBasic);
    }
  );
};

//delete one employees basic informatin
export const deleteBasicEmployee = (req, res) => {
  EmployeeBasic.remove(
    { _id: req.params.EmployeeBasicId },
    (err, employeeBasic) => {
      if (err) {
        res.send(err);
      }
      res.json({ message: "Employee basic information deleted" });
    }
  );
};

//secondary employee
const EmployeeSecondary = mongoose.model(
  "EmployeeSecondary",
  employeeSecondaryInfoSchema
);

// add secondary employee information
export const addNewEmployeeSecondaryInformation = (req, res) => {
  let newEmployee = new EmployeeSecondary(req.body);

  newEmployee.save((err, EmployeeSecondary) => {
    if (err) {
      res.send(err);
    }
    res.json(EmployeeSecondary);
  });
};

// get all employees secondary information
export const getEmployeesSecondary = (req, res) => {
  EmployeeSecondary.find({}, (err, EmployeeSecondary) => {
    if (err) {
      res.send(err);
    }
    res.json(EmployeeSecondary);
  });
};

//get one employees secondary information
export const getEmployeeSecondaryWithID = (req, res) => {
  EmployeeSecondary.findById(
    req.params.EmployeeSecondaryId,
    (err, EmployeeSecondary) => {
      if (err) {
        res.send(err);
      }
      res.json(EmployeeSecondary);
    }
  );
};

// update employees secondary information
export const updateSecondaryEmployee = (req, res) => {
  EmployeeSecondary.findOneAndUpdate(
    { _id: req.params.EmployeeSecondaryId },
    req.body,
    { new: true },
    (err, EmployeeSecondary) => {
      if (err) {
        res.send(err);
      }
      res.json(EmployeeSecondary);
    }
  );
};

//delete one employees secondary information
export const deleteSecondaryEmployee = (req, res) => {
  EmployeeSecondary.remove(
    { _id: req.params.EmployeeSecondaryId },
    (err, EmployeeSecondary) => {
      if (err) {
        res.send(err);
      }
      res.json({ message: "Employee secondary information deleted" });
    }
  );
};
