import React, { useState, useEffect } from "react";
import "./App.css";
import axios from "axios";
import EmployeeList from "./employee/EmployeeList";
import EmployeeSingle from "./employee/EmployeeSingle";
import EmployeeForm from "./employee/EmployeeForm";
import Footer from "./Footer/Footer";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      employees: [],
      currentEmployee: {},
    };

    this.updateCurrentEmployee = this.updateCurrentEmployee.bind(this);
  }

  componentDidMount() {
    const url = "http://localhost:5000/employeeBasic";
    axios
      .get(url)
      .then((Response) => {
        this.setState({
          employees: Response.data,
        });
      })
      .catch((error) => {
        console.log(error);
      });
    // .delete(`${url}/_id`)
    // .then(() => this.setState({ status: "Employee deleted."}));
  }

  updateCurrentEmployee(item) {
    this.setState({
      currentEmployee: item,
    });
  }

  render() {
    //for pagination
    //get current posts
    // const indexOfLastPost = currentPage * postsPerPage;
    // const indexOfFirstPost = indexOfLastPost - postsPerPage;
    // const currentPosts = employees.slice(indexOfFirstPost, indexOfLastPost);

    return (
      <div className="container-fluid">
        <div className="row">
          <nav>
            <div className="nav-wrapper teal darken-3">
              <a href="/" className="brand-logo">
                Employee Information
              </a>
              <ul id="nav-mobile" className="right hide-on-med-and-down">
                <li>
                  <a href="/employeeSecondary">Secondary Information</a>
                </li>
              </ul>
            </div>
          </nav>
        </div>
        <div className="row">
          <div className="col s3">
            <EmployeeList
              employees={this.state.employees}
              updateCurrentEmployee={this.updateCurrentEmployee}
            />
          </div>
          <div className="col s9">
            <EmployeeSingle employee={this.state.currentEmployee} />
          </div>
        </div>
        <div className="row">
          <div className="col s12">
            <EmployeeForm />
          </div>
        </div>
        <Footer />
      </div>
    );
  }
}

export default App;
