import React from "react";

const Footer = (props) => {
  return (
    <div>
      <ul>
        <li>Stephen Horton</li>
        <li>shorton4@student.douglascollege.ca | 778-994-2839</li>
      </ul>
    </div>
  );
};
export default Footer;
