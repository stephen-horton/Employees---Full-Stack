import React, { useState, useEffect } from "react";
import axios from "axios";

//for editing an employee
const EditEmployee = (props) => {
  const [employee, setEmployee] = useState(props.currentEmployee);
  useEffect(() => {
    setEmployee(props.currentEmployee);
  }, [props]);
  const handleInputChange = (event) => {
    const { emp, value } = event.target;
    setEmployee({ ...employee, [emp]: value });
  };
};

class EmployeeForm extends React.Component {
  submitEmployee(event) {
    event.preventDefault();
    axios
      .post("http://localhost:5000/employeeBasic", {
        first_name: this.refs.first_name.value,
        last_name: this.refs.last_name.value,
        gender: this.refs.gender.value,
        resume_received: this.refs.resume_received.value,
        coverletter_received: this.refs.coverletter_received.value,
      })
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  render() {
    return (
      <div className="row">
        <h5 className="left">For Admin Use:</h5>

        <form className="col s12" onSubmit={this.submitEmployee.bind(this)}>
        <h7>Please fill in ALL fields</h7>
          <div className="row">
            <div className="input-field col s6">
              <input
                id="first_name"
                ref="first_name"
                type="text" /*value={employee.first_name} onChange={handleInputChange}*/
              />
              <label htmlFor="first_name">First Name</label>
            </div>
            <div className="input-field col s6">
              <input
                id="last_name"
                ref="last_name"
                type="text" /*value={employee.last_name} onChange={handleInputChange}*/
              />
              <label htmlFor="last_name">Last Name</label>
            </div>
            <div className="input-field col s6">
              <input
                id="gender"
                ref="gender"
                type="text" /*value={employee.gender} onChange={handleInputChange}*/
              />
              <label htmlFor="gender">Gender</label>
            </div>
            <div className="input-field col s6">
              <input
                id="resume_received"
                ref="resume_received"
                type="text" /*value={employee.resume_received} onChange={handleInputChange}*/
              />
              <label htmlFor="resume_received">Resume Received</label>
            </div>
            <div className="input-field col s6">
              <input
                id="coverletter_received"
                ref="coverletter_received"
                type="text" /*value={employee.coverletter_received} onChange={handleInputChange}*/
              />
              <label htmlFor="coverletter_received">Coverletter Received</label>

            </div>
          </div>
          <button
            className="btn waves-effect waves-light btn-small"
            type="submit"
            name="action"
          >
            Add
          </button>
          <button
            className="btn waves-effect waves-light btn-small"
            // onClick={() => props.setEditing(false)}
            name="edit"
          >
            Edit
          </button>
        </form>
      </div>
    );
  }
}

export default EmployeeForm;
