import React, {useState, useEffect} from "react";

const EmployeeList = (props) => {

  return (
    <div>
      <ul className="collection with-header">
        <li className="collection-header">
          <h5>Employees</h5>
        </li>
        {props.employees.map((item) => (
          <a
            href="#!"
            className="collection-item"
            key={item._id}
            onClick={props.updateCurrentEmployee.bind(this, item)}>
            {item.first_name} {item.last_name}
          </a>
        ))}
      </ul>
    </div>
  );
};

export default EmployeeList;
