import React from "react";

const EmployeeSingle = (props) => {
 
  return (
    <div className="row">
      <div className="col s14">
        <div className="card">
          <div className="card-image">
            <img
              src="colleagues-looking-at-cheerful-businesswoman-in-meeting-875599880-5c04d3d6c9e77c00014e4910.jpg"
              alt="Employee Profile"
            />
            <span className="card-title">
              {props.employee.first_name} {props.employee.last_name}
            </span>
          </div>
          <div className="card-content">
            <p>
              First Name: {props.employee.first_name}
            </p>
          </div>
          <div className="card-content">
            <p>
              Last Name: {props.employee.last_name}
            </p>
          </div>
          <div className="card-action">Gender: {props.employee.gender}</div>
          <div className="card-action">
            Resume Received: {props.employee.resume_received}
          </div>
          <div className="card-action">
            Coverletter Received: {props.employee.coverletter_received}
          </div>
        </div>
      </div>
      <button
        className="btn waves-effect waves-light btn-small"
        type="submit"
        name="Delete">
          Delete
      </button>
    </div>
  );
};

export default EmployeeSingle;
